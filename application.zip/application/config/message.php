<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['message_prefix']	= '<p>';
$config['message_suffix']	= '</p>';
$config['message_folder']	= 'messages/';
$config['message_view']		= 'message'; // without the _view suffix
$config['wrapper_prefix']	= '<div class="message">';
$config['wrapper_suffix']	= '</div>';
